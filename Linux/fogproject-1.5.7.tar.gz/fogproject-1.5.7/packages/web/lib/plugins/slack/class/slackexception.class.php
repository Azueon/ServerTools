<?php
class SlackException extends Exception
{
}
