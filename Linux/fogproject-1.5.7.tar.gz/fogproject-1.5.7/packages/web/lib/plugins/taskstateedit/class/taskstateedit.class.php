<?php
/**
 * Taskstateeedit Class Handler.
 *
 * PHP version 5
 *
 * @category Taskstateedit
 * @package  FOGProject
 * @author   Tom Elliott <tommygunsster@gmail.com>
 * @license  http://opensource.org/licenses/gpl-3.0 GPLv3
 * @link     https://fogproject.org
 */
/**
 * Taskstateedit Class Handler.
 *
 * @category Taskstateedit
 * @package  FOGProject
 * @author   Tom Elliott <tommygunsster@gmail.com>
 * @license  http://opensource.org/licenses/gpl-3.0 GPLv3
 * @link     https://fogproject.org
 */
class Taskstateedit extends TaskState
{
}
